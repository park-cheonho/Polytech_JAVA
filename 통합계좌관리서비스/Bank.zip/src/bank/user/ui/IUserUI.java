package bank.user.ui;

public interface IUserUI {

	void execute() throws Exception;
}
