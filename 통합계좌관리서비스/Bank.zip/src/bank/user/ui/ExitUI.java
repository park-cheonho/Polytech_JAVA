package bank.user.ui;

public class ExitUI extends BaseUI {

	@Override
	public void execute() throws Exception {

		System.out.println("===================================");
		System.out.println("\n시스템을 종료합니다\n");
		System.out.println("\tBYE BYE~~~");
		System.out.println("===================================");
		System.exit(0);
	}

	
}
