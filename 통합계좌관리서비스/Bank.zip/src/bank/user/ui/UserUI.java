package bank.user.ui;

import java.util.Scanner;

import bank.user.ui.LoginUI;


public class UserUI extends BaseUI  {

	public int choiceMenu() {
		// TODO Auto-generated method stub
		System.out.println("------------------------------------------------------------------");
		System.out.println("\t통합 계좌 시스템입니다. ");
		System.out.println("[1].  로그인 ");
		System.out.println("[2].  회원가입");
		System.out.println("[0].  종료");
		System.out.println("------------------------------------------------------------------");
		int type=scanInt("원하는 메뉴를 선택하세요 : ");
		return type;
	}
	
	@Override
	public void execute() throws Exception{
		
		while(true) {
			int type = choiceMenu();
			IUserUI ui = null;
			switch (type) {
			case 1:
				ui = new LoginUI();
				break;
			case 0:
				ui = new ExitUI();
				break;
			}
			
			if(ui != null) {
				ui.execute();
			}
		}
		
	}

}
