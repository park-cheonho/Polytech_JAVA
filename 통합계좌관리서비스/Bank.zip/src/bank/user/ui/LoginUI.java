package bank.user.ui;

import java.util.List;
import java.util.Scanner;

import bank.user.service.UserService;
import bank.user.vo.UserVO;


public class LoginUI extends BaseUI {

	@Override
	public void execute() throws Exception {

		String id;
		Scanner sc = new Scanner(System.in);
		System.out.print("아이디 입력 : ");
		id = sc.nextLine();

		String pwd;
		System.out.println("비밀번호 입력 : ");
		pwd = sc.nextLine();
		
		
		/////////////////////////////////////////////////////
		// 메모리 or file or DB에 게시물을 저장하는 서비스
		UserVO newUser = new UserVO();
		newUser.setId(id);
		newUser.setPwd(pwd);
		
		userService.Login(newUser);
		/////////////////////////////////////////////////////

	}
}
