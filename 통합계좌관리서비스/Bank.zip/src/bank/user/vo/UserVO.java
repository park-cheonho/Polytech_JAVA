package bank.user.vo;

public class UserVO {
	private String id;
	private String pwd;
	private String phone;
	private int bool;
	
	public UserVO(){}
	
	public UserVO(String id, String pwd, String phone, int bool) {
		super();
		this.id = id;
		this.pwd = pwd;
		this.phone = phone;
		this.bool = 1;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getBool() {
		return bool;
	}

	public void setBool(int bool) {
		this.bool = 1;
	}

	@Override
	public String toString() {
		return "UserVO [id=" + id + ", pwd=" + pwd + ", phone=" + phone + ", bool=" + bool + "]";
	}

}
