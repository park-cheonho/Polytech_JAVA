package bank.user;

import bank.user.ui.UserUI;

public class UserMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			UserUI ui = new UserUI();
			ui.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
