package bank.user.service;

import java.util.List;

import bank.user.dao.UserDAO;
import bank.user.vo.UserVO;

public class UserService {
	private UserDAO userDAO;

	public UserService() {
		userDAO = new UserDAO();
	}
	
	public void Login(UserVO newUser) {
		
		userDAO.Login(newUser);
	}
	
	/*
	public List<BoardVO> selectAllBoard() {
		
		List<BoardVO> list = boardDAO.selectAllBoard();
		
		return list;
	}
	
	public BoardVO selectBoardByNo(int no) {
		
		BoardVO board = boardDAO.selectBoardByNo(no);
		return board;
		
	}
	
	public void modifyBoard(BoardVO board) {
		boardDAO.modifyBoard(board);
	}
	
	public void deleteBoardByNo(int no) {
		boardDAO.deleteBoardByNo(no);
	}
	*/

}
