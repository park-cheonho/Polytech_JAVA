package bank.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import bank.user.vo.UserVO;
import bank.util.ConnectionFactory;
import bank.util.JDBCClose;

public class UserDAO {

	private Connection conn;
	private PreparedStatement pstmt;
	
	/**
	 * 로그인 구현
	 */
	public void Login(UserVO newUser) {
		
		try {
			conn = new ConnectionFactory().getConnection();
			String Id = newUser.getId();
			
			StringBuffer sql = new StringBuffer();
			sql.append(" select * from t_user where id = ? ");
			
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, Id);
			
			ResultSet rs = pstmt.executeQuery();
			int cnt =rs.getFetchSize();
			
			String Pwd = newUser.getPwd();
			
			while(rs.next()) {
				String rspwd = rs.getString(2);            //컬럼   순서로  접근
				if(rspwd.equals(Pwd)) {
					System.out.println("로그인 성공!!");
				}else {
					System.out.println("로그인에 실패하셨습니다.");
				}
				//System.out.println(JOB_TITLE+"의 평균급여는 "+avg);
			}
			
			//System.out.println("userDAO");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCClose.close(conn, pstmt);
		}
	}
	
}









