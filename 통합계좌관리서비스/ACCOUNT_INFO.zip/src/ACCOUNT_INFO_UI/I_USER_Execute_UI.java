package ACCOUNT_INFO_UI;

public interface I_USER_Execute_UI {

	void execute() throws Exception;
}
