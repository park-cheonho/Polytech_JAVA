package ACCOUNT_INFO_UI;

public class ACCOUNT_Exit_UI extends ACCOUNT_InputOutput_UI {

	@Override
	public void execute() throws Exception {
		
		System.out.println("===================================");
		System.out.println("\n\t손님의 기쁨 그 하나를 위하여 \n");
		System.out.println("\t이용해 주셔서 감사합니다\n");
		System.out.println("===================================");
		System.exit(0);
		
	}

	
	
}
