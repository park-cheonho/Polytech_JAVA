package kr.ac.kopo.user.ui;

import kr.ac.kopo.account.ui.AccountUI;
import kr.ac.kopo.user.vo.UserVO;

public class LoginUI extends BaseUI {
	
	protected static String loginUserName;
	protected static String loginUserId;

	@Override
	public void execute() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("로그인 서비스 입니다");
		String id = scanStr("ID를 입력하세요 : ");
		String password = scanStr("비밀번호를 입력하세요 : ");

		//////////////////////////////////////////////////////
		// 메모리 or file or DB에 게시물을 저장하는 서비스
		UserVO user = userService.loginUser(id,password);
		
		System.out.println();
		if(user == null) {
			System.out.println("가입하지 않은 아이디이거나, 잘못된 비밀번호입니다.");
		} else {
			System.out.println("*********************************");
			System.out.println(" \t"+user.getName()+"님 환영합니다");
			System.out.println("*********************************");
			loginUserName = user.getName();
			loginUserId = user.getId();
			AccountUI ui = new AccountUI();
			try {
				ui.execute();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("---------------------------------");
	}

}
