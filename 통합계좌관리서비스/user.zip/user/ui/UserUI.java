package kr.ac.kopo.user.ui;

//사용자 입출력을 담당하는 클래스

public class UserUI extends BaseUI{

	@Override
	public void execute() throws Exception {
		// TODO Auto-generated method stub

		while(true) {
			int type = choiceMenu();

			IUserUI ui = null; // 할때마다 계속 독립적으로 만들어짐
			switch(type) {
			case 1:
				ui = new LoginUI();
				break;
			case 2:
				ui = new JoinUI();
				break;
			case 0:
				ui = new ExitUI();
				break;
			}
			if(ui!= null) {
				ui.execute();
			}
		}
	}

	private int choiceMenu() {
		// TODO Auto-generated method stub
		System.out.println("\n통합계좌 관리시스템(DB)");
		System.out.println("---------------------------------");
		System.out.println("1. 로그인");
		System.out.println("2. 회원가입");
		System.out.println("0. 종료");
		System.out.println("---------------------------------");

		int type = scanInt("번호를 선택하세요 : ");
		System.out.println("---------------------------------");
		return type;
	}



}