package kr.ac.kopo.user.ui;

import kr.ac.kopo.user.vo.UserVO;

public class JoinUI extends BaseUI{

	@Override
	public void execute() throws Exception {
		
		System.out.println("회원가입 서비스입니다");
		String id = scanStr("회원가입 할 ID를 입력하세요 : ");
		String password = scanStr("비밀번호를 입력하세요 : ");
		while(true) {
			String checkPassword = scanStr("비밀번호를 한번 더 입력하세요 : ");
			if(password.equals(checkPassword)) {
				break;
			}
		}
		String name = scanStr("이름을 입력하세요 : ");

		//////////////////////////////////////////////////////
		// 메모리 or file or DB에 게시물을 저장하는 서비스
		UserVO newUser = new UserVO();
		newUser.setId(id);
		newUser.setPassword(password);
		newUser.setName(name);
		
		userService.insertUser(newUser);
		//////////////////////////////////////////////////////
		
		System.out.println("회원가입을 완료하였습니다");
	}
}