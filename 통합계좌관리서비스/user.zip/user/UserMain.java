package kr.ac.kopo.user;

import kr.ac.kopo.user.ui.UserUI;

public class UserMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		UserUI ui = new UserUI();
		try {
			ui.execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}