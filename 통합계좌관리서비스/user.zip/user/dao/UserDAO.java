package kr.ac.kopo.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import kr.ac.kopo.user.vo.UserVO;
import kr.ac.kopo.util.ConnectionFactory;
import kr.ac.kopo.util.JDBCClose;

public class UserDAO {

	private Connection conn;
	private PreparedStatement pstmt;

	private List<UserVO> list;

	/**
	 * 새로운 User를 등록하는 기능
	 */
	public void insertUser(UserVO newUser) {

		try {
			conn = new ConnectionFactory().getConnection();

			StringBuilder sql = new StringBuilder();

			sql.append("INSERT INTO USERS(SEQ, ID, PASSWORD,NAME)  ");
			sql.append(" VALUES(USER_SEQUENCE.NEXTVAL,?,?,?)");

			pstmt = conn.prepareStatement(sql.toString());
			String id = newUser.getId();
			String password = newUser.getPassword();
			String name = newUser.getName();

			pstmt.setString(1, id);
			pstmt.setString(2, password);
			pstmt.setString(3, name);

			pstmt.executeUpdate();

		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			JDBCClose.close(conn, pstmt);
		}
	}

	public UserVO loginUser(String id, String password) {
		// TODO Auto-generated method stub
		UserVO user = null;
		try {
			conn = new ConnectionFactory().getConnection();

			StringBuilder sql = new StringBuilder();

			sql.append("SELECT SEQ, ID, PASSWORD, NAME, REGDATE ");
			sql.append(" FROM USERS ");
			sql.append(" WHERE ID =? AND PASSWORD = ? ");

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, password);

			ResultSet rs = pstmt.executeQuery();

			if(rs.next()) {

				int seq = rs.getInt("SEQ");
				String name = rs.getString("NAME");
				String regDate = rs.getString("REGDATE");
				
				user = new UserVO(seq,id,password,name,regDate);
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			JDBCClose.close(conn, pstmt);
		}
		
		return user;
	}

	/**
	 * 번호에 해당하는 게시물을 수정하는 기능
	 */

	/**
	 * 번호에 해당하는 게시물을 삭제하는 기능
	 */
}