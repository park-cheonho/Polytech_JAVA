package kr.ac.kopo.user.service;

public class BoardSequence {
	
	private static int boardNo = 1;
	
	public static int getBoardSequence() {
		return boardNo++;
	}
}