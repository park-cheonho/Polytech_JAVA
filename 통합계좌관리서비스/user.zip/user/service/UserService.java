package kr.ac.kopo.user.service;

import java.util.List;

import kr.ac.kopo.user.dao.UserDAO;
import kr.ac.kopo.user.vo.UserVO;

/* 
 * 	 --->		--->
 * UI 	 SERVICE	DAO
 * 	 <---	    <---

 */
public class UserService {
	private UserDAO userDAO;
	
	public UserService() {
		userDAO = new UserDAO();
	}
	public void insertUser(UserVO newBoard) {
		userDAO.insertUser(newBoard);
		// uservo를 ui에서 입력받고 service에 넘겨서 번호랑 date입력하고 userdao에서 리스트에 저장
	}
	/*
	public List<UserVO> selectAllBoard() {
		// TODO Auto-generated method stub
		List<UserVO> list = userDAO.selectAllBoard();
		return list;
	}
	*/
	public UserVO loginUser(String id, String password) {
		// TODO Auto-generated method stub
		UserVO user = userDAO.loginUser(id,password);
		return user;
	}
}